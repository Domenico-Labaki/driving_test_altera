// track_renderer.v — Pixel color determination for VGA output.
//
// Color priority (high→low):
//   Car (yellow) > Cone (orange) > SF line (white) > Building > Track (black) > Off-road (green)
//
// The is_on_track function encodes the DXF boundary geometry from track_data.vh.
// All arithmetic is integer; no floating point.

`include "track_data.vh"

module track_renderer (
    input  wire        pclk,
    input  wire        rst_n,
    input  wire        active,
    input  wire [9:0]  px,
    input  wire [9:0]  py,
    // Car
    input  wire [9:0]  car_x,
    input  wire [9:0]  car_y,
    input  wire [2:0]  car_angle,
    // Sprite rows packed: row k = car_row_bus[k*8 +: 8]
    input  wire [111:0] car_row_bus,
    output reg  [23:0] rgb
);

// ── Color constants ───────────────────────────────────────────────────────
localparam C_TRACK    = 24'h000000;
localparam C_OFFROAD  = 24'h00AA00;
localparam C_CONE     = 24'hFF8800;
localparam C_CAR      = 24'hFFFF00;
localparam C_BLDG     = 24'h444444;
localparam C_BLDG_OUT = 24'h666666;
localparam C_WIN      = 24'hFFFF99;
localparam C_SF_MARK  = 24'hFFFFFF;

// ─────────────────────────────────────────────────────────────────────────
//  is_on_track — pure combinational; returns 1 when pixel is drivable road
// ─────────────────────────────────────────────────────────────────────────
function [0:0] is_on_track;
    input [9:0] fpx, fpy;
    reg signed [20:0] cross2, cross3, cross4;
    reg in_inner;
    begin
        is_on_track = 1'b0;

        // Outer boundary
        if (fpx < `OUTER_LEFT  || fpx > `OUTER_RIGHT ||
            fpy < `OUTER_TOP   || fpy > `OUTER_BOTTOM) begin
            is_on_track = 1'b0;

        // Top-right rounded corner: off-track when (px-590)*38 > (58-py)*30
        end else if (fpx > `TR_CORNER_X && fpy < `TR_CORNER_Y) begin
            if (($unsigned(fpx) - 10'd590) * 10'd38 <=
                (10'd58 - $unsigned(fpy)) * 10'd30)
                is_on_track = 1'b1;

        // Bottom-right rounded corner: off-track when (px-581)*30 < (py-350)*39
        end else if (fpx > `BR_CORNER_X && fpy > `BR_CORNER_Y) begin
            if (($unsigned(fpx) - 10'd581) * 10'd30 >=
                ($unsigned(fpy) - 10'd350) * 10'd39)
                is_on_track = 1'b1;

        end else begin
            in_inner = 1'b0;

            // ── V-notch island (entities 1–4) ─────────────────────────
            // Polygon: (29,91)→(186,91)→(83,178)→(117,219)→(274,91)
            if (fpy >= `INNER_TL_Y && fpx >= `INNER_TL_X1 && fpx <= `ISLAND_TOP_X1) begin
                // Entity 2: (186,91)→(83,178): cross = -103*(py-91) - 87*(px-186)
                cross2 = -21'sd103 * $signed({1'b0, fpy} - 10'd91)
                         - 21'sd87  * $signed({1'b0, fpx} - 10'd186);
                // Entity 3: (83,178)→(117,219): cross = 34*(py-178) - 41*(px-83)
                cross3 = 21'sd34 * $signed({1'b0, fpy} - 10'd178)
                         - 21'sd41 * $signed({1'b0, fpx} - 10'd83);
                // Entity 4: (117,219)→(274,91): cross = 157*(py-219)+128*(px-117)
                cross4 = 21'sd157 * $signed({1'b0, fpy} - 10'd219)
                         + 21'sd128 * $signed({1'b0, fpx} - 10'd117);

                if (fpy <= `E2_Y2) begin
                    // Above entity-3 start: island left of entity-2
                    if (cross2 < 21'sd0) in_inner = 1'b1;
                end else if (fpy <= `E3_Y2) begin
                    // Entity-3 zone: inside when both cross3<0 and cross4<0
                    if (cross3 < 21'sd0 && cross4 < 21'sd0) in_inner = 1'b1;
                end
            end

            // ── Main right island [274..543]×[90..314] ─────────────────
            if (fpx >= `ISLAND_BX1 && fpx <= `ISLAND_BX2 &&
                fpy >= `ISLAND_BY1 && fpy <= `ISLAND_BY2) begin

                // Staircase pocket on right side — this is ON-TRACK
                if (fpx >= `STEP_CUTOUT_X1 && fpx <= `STEP_CUTOUT_X2 &&
                    fpy >= `STEP_CUTOUT_Y1 && fpy <= `STEP_CUTOUT_Y2) begin
                    // Track — do nothing
                end
                // Lower-right step extension — OFF-TRACK
                else if (fpx >= `STEP_LR_X1 && fpx <= `STEP_LR_X2 &&
                         fpy >= `STEP_LR_Y1 && fpy <= `STEP_LR_Y2) begin
                    in_inner = 1'b1;
                end
                // Left wall portion (x≥318, y≥103)
                else if (fpx >= `ISLAND_LEFT_X && fpy >= `ISLAND_LEFT_Y1) begin
                    in_inner = 1'b1;
                end
                // Top strip (x<318, y in [90,103))
                else if (fpx < `ISLAND_LEFT_X && fpy < `ISLAND_LEFT_Y1) begin
                    in_inner = 1'b1;
                end
            end

            // ── Bottom-left shelf [103..237]×[260..319] ────────────────
            if (fpx >= `BOT_LEFT_X1 && fpx <= `BOT_LEFT_X2 &&
                fpy >= `BOT_LEFT_Y1 && fpy <= `BOT_LEFT_Y2)
                in_inner = 1'b1;

            // ── Bottom mid [237..507]×[319..314] ───────────────────────
            if (fpx >= `BOT_LEFT_X2 && fpx <= `BOT_EXT_X1 &&
                fpy >= `BOT_INNER_Y && fpy <= `ISLAND_BY2)
                in_inner = 1'b1;

            // ── Bottom-right extension [507..543]×[314..319] ───────────
            if (fpx >= `BOT_EXT_X1 && fpx <= `BOT_EXT_X2 &&
                fpy >= `BOT_EXT_Y1 && fpy <= `BOT_EXT_Y2)
                in_inner = 1'b1;

            is_on_track = ~in_inner;
        end
    end
endfunction

// ─────────────────────────────────────────────────────────────────────────
//  Cone pixel: diamond shape, radius 3
// ─────────────────────────────────────────────────────────────────────────
function [0:0] is_cone_pixel;
    input [9:0] fpx, fpy;
    reg [10:0] dx, dy;
    // All 10 cone checks expanded (no loop — loop-carried arrays don't synthesize)
    begin
        is_cone_pixel = 1'b0;
        // Cone 0: (108,135)
        dx = (fpx>=10'd108) ? fpx-10'd108 : 10'd108-fpx;
        dy = (fpy>=10'd135) ? fpy-10'd135 : 10'd135-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 1: (83,178)
        dx = (fpx>=10'd83)  ? fpx-10'd83  : 10'd83-fpx;
        dy = (fpy>=10'd178) ? fpy-10'd178 : 10'd178-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 2: (117,219)
        dx = (fpx>=10'd117) ? fpx-10'd117 : 10'd117-fpx;
        dy = (fpy>=10'd219) ? fpy-10'd219 : 10'd219-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 3: (210,91)
        dx = (fpx>=10'd210) ? fpx-10'd210 : 10'd210-fpx;
        dy = (fpy>=10'd91)  ? fpy-10'd91  : 10'd91-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 4: (400,55)
        dx = (fpx>=10'd400) ? fpx-10'd400 : 10'd400-fpx;
        dy = (fpy>=10'd55)  ? fpy-10'd55  : 10'd55-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 5: (580,135)
        dx = (fpx>=10'd580) ? fpx-10'd580 : 10'd580-fpx;
        dy = (fpy>=10'd135) ? fpy-10'd135 : 10'd135-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 6: (580,320)
        dx = (fpx>=10'd580) ? fpx-10'd580 : 10'd580-fpx;
        dy = (fpy>=10'd320) ? fpy-10'd320 : 10'd320-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 7: (420,350)
        dx = (fpx>=10'd420) ? fpx-10'd420 : 10'd420-fpx;
        dy = (fpy>=10'd350) ? fpy-10'd350 : 10'd350-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 8: (170,350)
        dx = (fpx>=10'd170) ? fpx-10'd170 : 10'd170-fpx;
        dy = (fpy>=10'd350) ? fpy-10'd350 : 10'd350-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
        // Cone 9: (50,260)
        dx = (fpx>=10'd50)  ? fpx-10'd50  : 10'd50-fpx;
        dy = (fpy>=10'd260) ? fpy-10'd260 : 10'd260-fpy;
        if (dx+dy <= 11'd3) is_cone_pixel = 1'b1;
    end
endfunction

// ─────────────────────────────────────────────────────────────────────────
//  Car sprite pixel
// ─────────────────────────────────────────────────────────────────────────
function [0:0] car_pixel;
    input [9:0] fpx, fpy, carx, cary;
    input [111:0] row_bus;
    reg [9:0] rel_x, rel_y;
    reg [7:0] row_bits;
    begin
        car_pixel = 1'b0;
        if (fpx >= carx - 10'd4 && fpx < carx + 10'd4 &&
            fpy >= cary - 10'd7 && fpy < cary + 10'd7) begin
            rel_x = fpx - (carx - 10'd4);
            rel_y = fpy - (cary - 10'd7);
            // Extract row from flat bus using part-select
            row_bits = row_bus[rel_y[3:0]*8 +: 8];
            car_pixel = row_bits[7 - rel_x[2:0]];
        end
    end
endfunction

// ─────────────────────────────────────────────────────────────────────────
//  Building color — returns non-zero color if pixel is inside a building
//  (returns 24'h000000 = C_TRACK as "no building" sentinel)
// ─────────────────────────────────────────────────────────────────────────
// Building table: {bx[9:0], by[9:0], bw[6:0], bh[6:0]} per building
// Packed as 36-bit entries
function [23:0] bldg_color;
    input [9:0] fpx, fpy;
    // Building data: x, y, w, h
    reg [9:0] bx, by;
    reg [6:0] bw, bh;
    reg hit;
    reg [3:0] widx, hidx;
    begin
        bldg_color = 24'h000000;
        hit = 1'b0;

        // Building 0: x=300,y=105,w=32,h=40
        if (!hit && fpx>=300 && fpx<332 && fpy>=105 && fpy<145) begin
            hit=1; bx=300; by=105; bw=32; bh=40; end
        // Building 1: x=360,y=115,w=24,h=30
        if (!hit && fpx>=360 && fpx<384 && fpy>=115 && fpy<145) begin
            hit=1; bx=360; by=115; bw=24; bh=30; end
        // Building 2: x=410,y=108,w=20,h=50
        if (!hit && fpx>=410 && fpx<430 && fpy>=108 && fpy<158) begin
            hit=1; bx=410; by=108; bw=20; bh=50; end
        // Building 3: x=340,y=200,w=40,h=60
        if (!hit && fpx>=340 && fpx<380 && fpy>=200 && fpy<260) begin
            hit=1; bx=340; by=200; bw=40; bh=60; end
        // Building 4: x=300,y=210,w=28,h=45
        if (!hit && fpx>=300 && fpx<328 && fpy>=210 && fpy<255) begin
            hit=1; bx=300; by=210; bw=28; bh=45; end
        // Building 5: x=460,y=180,w=36,h=80
        if (!hit && fpx>=460 && fpx<496 && fpy>=180 && fpy<260) begin
            hit=1; bx=460; by=180; bw=36; bh=80; end
        // Building 6: x=150,y=300,w=30,h=35
        if (!hit && fpx>=150 && fpx<180 && fpy>=300 && fpy<335) begin
            hit=1; bx=150; by=300; bw=30; bh=35; end
        // Building 7: x=350,y=330,w=40,h=28
        if (!hit && fpx>=350 && fpx<390 && fpy>=330 && fpy<358) begin
            hit=1; bx=350; by=330; bw=40; bh=28; end

        if (hit) begin
            // Outline (1-px border)
            if (fpx == bx || fpx == bx+{3'b0,bw}-10'd1 ||
                fpy == by || fpy == by+{3'b0,bh}-10'd1)
                bldg_color = C_BLDG_OUT;
            // Windows: 2×2 bright yellow on 6×8 grid with 2-px margin
            else if (((fpx - bx - 10'd2) % 10'd6 < 10'd2) &&
                     ((fpy - by - 10'd3) % 10'd8 < 10'd2))
                bldg_color = C_WIN;
            else
                bldg_color = C_BLDG;
        end
    end
endfunction

// ─────────────────────────────────────────────────────────────────────────
//  Combinational wires
// ─────────────────────────────────────────────────────────────────────────
wire        w_car   = car_pixel(px, py, car_x, car_y, car_row_bus);
wire        w_cone  = is_cone_pixel(px, py);
wire        w_sf    = (px == `SF_X2) && (py >= `SF_Y1) && (py <= `SF_Y2);
wire        w_track = is_on_track(px, py);
wire [23:0] w_bldg  = bldg_color(px, py);

// ─────────────────────────────────────────────────────────────────────────
//  Registered pixel pipeline
// ─────────────────────────────────────────────────────────────────────────
always @(posedge pclk) begin
    if (!rst_n || !active)
        rgb <= 24'h000000;
    else if (w_car)
        rgb <= C_CAR;
    else if (w_cone)
        rgb <= C_CONE;
    else if (w_sf)
        rgb <= C_SF_MARK;
    else if (w_bldg != 24'h000000 && !w_track)
        rgb <= w_bldg;
    else if (w_track)
        rgb <= C_TRACK;
    else
        rgb <= C_OFFROAD;
end

endmodule
