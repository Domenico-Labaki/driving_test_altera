// car_sprites.vh — 8 pre-computed car sprite orientations
//
// Car is 8 wide × 14 tall pixels (bounding box).
// Each sprite is a 14×8 bit array (row-major, MSB = left column).
// angle[2:0]: 0=East, 1=NE, 2=North, 3=NW, 4=West, 5=SW, 6=South, 7=SE
//
// Bit layout per row: bit[7] = leftmost pixel, bit[0] = rightmost pixel
// A '1' bit means draw the car pixel (yellow).

// Sprite dimensions
`define SPR_W  8   // width in pixels
`define SPR_H 14   // height in pixels

// ── angle 0 — East (car pointing right) ──────────────────────────────────
// Tall narrow shape (8w × 14h), car body oriented left-right
`define SPR_0_R00  8'b00111100
`define SPR_0_R01  8'b01111110
`define SPR_0_R02  8'b11111111
`define SPR_0_R03  8'b11111111
`define SPR_0_R04  8'b11111111
`define SPR_0_R05  8'b11111111
`define SPR_0_R06  8'b11111111
`define SPR_0_R07  8'b11111111
`define SPR_0_R08  8'b11111111
`define SPR_0_R09  8'b11111111
`define SPR_0_R10  8'b11111111
`define SPR_0_R11  8'b11111111
`define SPR_0_R12  8'b01111110
`define SPR_0_R13  8'b00111100

// ── angle 1 — NE (45°) ────────────────────────────────────────────────────
`define SPR_1_R00  8'b00001110
`define SPR_1_R01  8'b00011111
`define SPR_1_R02  8'b00111111
`define SPR_1_R03  8'b01111110
`define SPR_1_R04  8'b11111100
`define SPR_1_R05  8'b11111000
`define SPR_1_R06  8'b11110000
`define SPR_1_R07  8'b11100000
`define SPR_1_R08  8'b11110000
`define SPR_1_R09  8'b11111000
`define SPR_1_R10  8'b11111100
`define SPR_1_R11  8'b01111110
`define SPR_1_R12  8'b00111111
`define SPR_1_R13  8'b00001110

// ── angle 2 — North (car pointing up) ────────────────────────────────────
`define SPR_2_R00  8'b00011000
`define SPR_2_R01  8'b00111100
`define SPR_2_R02  8'b01111110
`define SPR_2_R03  8'b11111111
`define SPR_2_R04  8'b11111111
`define SPR_2_R05  8'b11111111
`define SPR_2_R06  8'b01111110
`define SPR_2_R07  8'b01111110
`define SPR_2_R08  8'b01111110
`define SPR_2_R09  8'b11111111
`define SPR_2_R10  8'b11111111
`define SPR_2_R11  8'b11111111
`define SPR_2_R12  8'b01111110
`define SPR_2_R13  8'b00111100

// ── angle 3 — NW (135°) ───────────────────────────────────────────────────
`define SPR_3_R00  8'b01110000
`define SPR_3_R01  8'b11111000
`define SPR_3_R02  8'b11111100
`define SPR_3_R03  8'b01111110
`define SPR_3_R04  8'b00111111
`define SPR_3_R05  8'b00011111
`define SPR_3_R06  8'b00001111
`define SPR_3_R07  8'b00000111
`define SPR_3_R08  8'b00001111
`define SPR_3_R09  8'b00011111
`define SPR_3_R10  8'b00111111
`define SPR_3_R11  8'b01111110
`define SPR_3_R12  8'b11111100
`define SPR_3_R13  8'b01110000

// ── angle 4 — West (car pointing left, mirror of angle 0) ────────────────
`define SPR_4_R00  8'b00111100
`define SPR_4_R01  8'b01111110
`define SPR_4_R02  8'b11111111
`define SPR_4_R03  8'b11111111
`define SPR_4_R04  8'b11111111
`define SPR_4_R05  8'b11111111
`define SPR_4_R06  8'b11111111
`define SPR_4_R07  8'b11111111
`define SPR_4_R08  8'b11111111
`define SPR_4_R09  8'b11111111
`define SPR_4_R10  8'b11111111
`define SPR_4_R11  8'b11111111
`define SPR_4_R12  8'b01111110
`define SPR_4_R13  8'b00111100

// ── angle 5 — SW (225°) ───────────────────────────────────────────────────
`define SPR_5_R00  8'b00001110
`define SPR_5_R01  8'b00011111
`define SPR_5_R02  8'b00111111
`define SPR_5_R03  8'b01111110
`define SPR_5_R04  8'b11111100
`define SPR_5_R05  8'b11111000
`define SPR_5_R06  8'b11110000
`define SPR_5_R07  8'b11100000
`define SPR_5_R08  8'b11110000
`define SPR_5_R09  8'b11111000
`define SPR_5_R10  8'b11111100
`define SPR_5_R11  8'b01111110
`define SPR_5_R12  8'b00111111
`define SPR_5_R13  8'b00001110

// ── angle 6 — South (car pointing down, mirror of angle 2) ───────────────
`define SPR_6_R00  8'b00111100
`define SPR_6_R01  8'b01111110
`define SPR_6_R02  8'b11111111
`define SPR_6_R03  8'b11111111
`define SPR_6_R04  8'b11111111
`define SPR_6_R05  8'b01111110
`define SPR_6_R06  8'b01111110
`define SPR_6_R07  8'b01111110
`define SPR_6_R08  8'b11111111
`define SPR_6_R09  8'b11111111
`define SPR_6_R10  8'b11111111
`define SPR_6_R11  8'b01111110
`define SPR_6_R12  8'b00111100
`define SPR_6_R13  8'b00011000

// ── angle 7 — SE (315°) ───────────────────────────────────────────────────
`define SPR_7_R00  8'b01110000
`define SPR_7_R01  8'b11111000
`define SPR_7_R02  8'b11111100
`define SPR_7_R03  8'b01111110
`define SPR_7_R04  8'b00111111
`define SPR_7_R05  8'b00011111
`define SPR_7_R06  8'b00001111
`define SPR_7_R07  8'b00000111
`define SPR_7_R08  8'b00001111
`define SPR_7_R09  8'b00011111
`define SPR_7_R10  8'b00111111
`define SPR_7_R11  8'b01111110
`define SPR_7_R12  8'b11111100
`define SPR_7_R13  8'b01110000
