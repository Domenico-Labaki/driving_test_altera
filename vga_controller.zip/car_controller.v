// car_controller.v — Car physics: position, heading, speed.
//
// Fixed-point Q8.8 throughout (16-bit signed).
// Sprite rows exported as flat 112-bit bus: car_row_bus[k*8 +: 8] = row k.
//
// Angle steps (8×45°): 0=E  1=NE  2=N  3=NW  4=W  5=SW  6=S  7=SE
// Game-logic update occurs on each tick_60hz pulse (60 Hz, from vsync).

`include "car_sprites.vh"
`include "track_data.vh"

module car_controller (
    input  wire        clk50,
    input  wire        rst_n,
    input  wire        tick_60hz,
    input  wire        accel,
    input  wire        brake,
    input  wire        steer_left,
    input  wire        steer_right,
    input  wire        game_active,
    output reg  [9:0]  car_x,
    output reg  [9:0]  car_y,
    output reg  [2:0]  car_angle,
    output reg  [7:0]  speed_kph,
    // 14 sprite rows packed into one bus: row k = car_row_bus[k*8 +: 8]
    output reg  [111:0] car_row_bus
);

// ── Speed limits (Q8.8) ───────────────────────────────────────────────────
localparam signed [15:0] SPD_MAX   =  16'sh0400;  // +4.0 px/frame
localparam signed [15:0] SPD_MIN   = -16'sh0180;  // -1.5 px/frame (reverse)
localparam signed [15:0] SPD_ACCEL =  16'sh0014;  // 0.08 px/frame per tick
localparam signed [15:0] SPD_BRAKE =  16'sh001E;  // 0.12 px/frame per tick
localparam signed [15:0] SPD_DRAG  =  16'sh000A;  // 0.04 px/frame drag

// ── cos/sin LUT: 256 * {cos,sin}(angle×45°), Y-down convention ───────────
//   angle: 0=E    1=NE   2=N    3=NW   4=W    5=SW   6=S    7=SE
//   cos:  +256,  +181,    0,  -181,  -256,  -181,    0,  +181
//   sin:    0,   +181, +256,  +181,    0,   -181, -256,  -181  (Y↓)
reg signed [15:0] cos_lut [0:7];
reg signed [15:0] sin_lut [0:7];

initial begin
    cos_lut[0] =  16'sh0100; cos_lut[1] =  16'sh00B5;
    cos_lut[2] =  16'sh0000; cos_lut[3] = -16'sh00B5;
    cos_lut[4] = -16'sh0100; cos_lut[5] = -16'sh00B5;
    cos_lut[6] =  16'sh0000; cos_lut[7] =  16'sh00B5;

    sin_lut[0] =  16'sh0000; sin_lut[1] =  16'sh00B5;
    sin_lut[2] =  16'sh0100; sin_lut[3] =  16'sh00B5;
    sin_lut[4] =  16'sh0000; sin_lut[5] = -16'sh00B5;
    sin_lut[6] = -16'sh0100; sin_lut[7] = -16'sh00B5;
end

// ── Sprite ROM: 8 angles × 14 rows × 8 bits ──────────────────────────────
reg [7:0] sprite_rom [0:7][0:13];

initial begin
    sprite_rom[0][0]  = `SPR_0_R00; sprite_rom[0][1]  = `SPR_0_R01;
    sprite_rom[0][2]  = `SPR_0_R02; sprite_rom[0][3]  = `SPR_0_R03;
    sprite_rom[0][4]  = `SPR_0_R04; sprite_rom[0][5]  = `SPR_0_R05;
    sprite_rom[0][6]  = `SPR_0_R06; sprite_rom[0][7]  = `SPR_0_R07;
    sprite_rom[0][8]  = `SPR_0_R08; sprite_rom[0][9]  = `SPR_0_R09;
    sprite_rom[0][10] = `SPR_0_R10; sprite_rom[0][11] = `SPR_0_R11;
    sprite_rom[0][12] = `SPR_0_R12; sprite_rom[0][13] = `SPR_0_R13;

    sprite_rom[1][0]  = `SPR_1_R00; sprite_rom[1][1]  = `SPR_1_R01;
    sprite_rom[1][2]  = `SPR_1_R02; sprite_rom[1][3]  = `SPR_1_R03;
    sprite_rom[1][4]  = `SPR_1_R04; sprite_rom[1][5]  = `SPR_1_R05;
    sprite_rom[1][6]  = `SPR_1_R06; sprite_rom[1][7]  = `SPR_1_R07;
    sprite_rom[1][8]  = `SPR_1_R08; sprite_rom[1][9]  = `SPR_1_R09;
    sprite_rom[1][10] = `SPR_1_R10; sprite_rom[1][11] = `SPR_1_R11;
    sprite_rom[1][12] = `SPR_1_R12; sprite_rom[1][13] = `SPR_1_R13;

    sprite_rom[2][0]  = `SPR_2_R00; sprite_rom[2][1]  = `SPR_2_R01;
    sprite_rom[2][2]  = `SPR_2_R02; sprite_rom[2][3]  = `SPR_2_R03;
    sprite_rom[2][4]  = `SPR_2_R04; sprite_rom[2][5]  = `SPR_2_R05;
    sprite_rom[2][6]  = `SPR_2_R06; sprite_rom[2][7]  = `SPR_2_R07;
    sprite_rom[2][8]  = `SPR_2_R08; sprite_rom[2][9]  = `SPR_2_R09;
    sprite_rom[2][10] = `SPR_2_R10; sprite_rom[2][11] = `SPR_2_R11;
    sprite_rom[2][12] = `SPR_2_R12; sprite_rom[2][13] = `SPR_2_R13;

    sprite_rom[3][0]  = `SPR_3_R00; sprite_rom[3][1]  = `SPR_3_R01;
    sprite_rom[3][2]  = `SPR_3_R02; sprite_rom[3][3]  = `SPR_3_R03;
    sprite_rom[3][4]  = `SPR_3_R04; sprite_rom[3][5]  = `SPR_3_R05;
    sprite_rom[3][6]  = `SPR_3_R06; sprite_rom[3][7]  = `SPR_3_R07;
    sprite_rom[3][8]  = `SPR_3_R08; sprite_rom[3][9]  = `SPR_3_R09;
    sprite_rom[3][10] = `SPR_3_R10; sprite_rom[3][11] = `SPR_3_R11;
    sprite_rom[3][12] = `SPR_3_R12; sprite_rom[3][13] = `SPR_3_R13;

    sprite_rom[4][0]  = `SPR_4_R00; sprite_rom[4][1]  = `SPR_4_R01;
    sprite_rom[4][2]  = `SPR_4_R02; sprite_rom[4][3]  = `SPR_4_R03;
    sprite_rom[4][4]  = `SPR_4_R04; sprite_rom[4][5]  = `SPR_4_R05;
    sprite_rom[4][6]  = `SPR_4_R06; sprite_rom[4][7]  = `SPR_4_R07;
    sprite_rom[4][8]  = `SPR_4_R08; sprite_rom[4][9]  = `SPR_4_R09;
    sprite_rom[4][10] = `SPR_4_R10; sprite_rom[4][11] = `SPR_4_R11;
    sprite_rom[4][12] = `SPR_4_R12; sprite_rom[4][13] = `SPR_4_R13;

    sprite_rom[5][0]  = `SPR_5_R00; sprite_rom[5][1]  = `SPR_5_R01;
    sprite_rom[5][2]  = `SPR_5_R02; sprite_rom[5][3]  = `SPR_5_R03;
    sprite_rom[5][4]  = `SPR_5_R04; sprite_rom[5][5]  = `SPR_5_R05;
    sprite_rom[5][6]  = `SPR_5_R06; sprite_rom[5][7]  = `SPR_5_R07;
    sprite_rom[5][8]  = `SPR_5_R08; sprite_rom[5][9]  = `SPR_5_R09;
    sprite_rom[5][10] = `SPR_5_R10; sprite_rom[5][11] = `SPR_5_R11;
    sprite_rom[5][12] = `SPR_5_R12; sprite_rom[5][13] = `SPR_5_R13;

    sprite_rom[6][0]  = `SPR_6_R00; sprite_rom[6][1]  = `SPR_6_R01;
    sprite_rom[6][2]  = `SPR_6_R02; sprite_rom[6][3]  = `SPR_6_R03;
    sprite_rom[6][4]  = `SPR_6_R04; sprite_rom[6][5]  = `SPR_6_R05;
    sprite_rom[6][6]  = `SPR_6_R06; sprite_rom[6][7]  = `SPR_6_R07;
    sprite_rom[6][8]  = `SPR_6_R08; sprite_rom[6][9]  = `SPR_6_R09;
    sprite_rom[6][10] = `SPR_6_R10; sprite_rom[6][11] = `SPR_6_R11;
    sprite_rom[6][12] = `SPR_6_R12; sprite_rom[6][13] = `SPR_6_R13;

    sprite_rom[7][0]  = `SPR_7_R00; sprite_rom[7][1]  = `SPR_7_R01;
    sprite_rom[7][2]  = `SPR_7_R02; sprite_rom[7][3]  = `SPR_7_R03;
    sprite_rom[7][4]  = `SPR_7_R04; sprite_rom[7][5]  = `SPR_7_R05;
    sprite_rom[7][6]  = `SPR_7_R06; sprite_rom[7][7]  = `SPR_7_R07;
    sprite_rom[7][8]  = `SPR_7_R08; sprite_rom[7][9]  = `SPR_7_R09;
    sprite_rom[7][10] = `SPR_7_R10; sprite_rom[7][11] = `SPR_7_R11;
    sprite_rom[7][12] = `SPR_7_R12; sprite_rom[7][13] = `SPR_7_R13;
end

// ── Q8.8 position and speed registers ────────────────────────────────────
reg signed [17:0] pos_x_q8;
reg signed [17:0] pos_y_q8;
reg signed [15:0] speed_q8;

reg signed [33:0] dx_q16;
reg signed [33:0] dy_q16;
integer r;

// Helper: pack sprite rows into flat bus for a given angle
task pack_sprite_bus;
    input [2:0] ang;
    integer i;
    begin
        for (i = 0; i < 14; i = i + 1)
            car_row_bus[i*8 +: 8] <= sprite_rom[ang][i];
    end
endtask

always @(posedge clk50) begin
    if (!rst_n) begin
        pos_x_q8  <= {2'b00, `CAR_START_X, 8'd0};
        pos_y_q8  <= {2'b00, `CAR_START_Y, 8'd0};
        speed_q8  <= 16'sh0000;
        car_angle <= `CAR_START_ANGLE;
        car_x     <= `CAR_START_X;
        car_y     <= `CAR_START_Y;
        speed_kph <= 8'd0;
        for (r = 0; r < 14; r = r + 1)
            car_row_bus[r*8 +: 8] <= sprite_rom[`CAR_START_ANGLE][r];
    end else if (!game_active) begin
        pos_x_q8  <= {2'b00, `CAR_START_X, 8'd0};
        pos_y_q8  <= {2'b00, `CAR_START_Y, 8'd0};
        speed_q8  <= 16'sh0000;
        car_angle <= `CAR_START_ANGLE;
        car_x     <= `CAR_START_X;
        car_y     <= `CAR_START_Y;
        speed_kph <= 8'd0;
        for (r = 0; r < 14; r = r + 1)
            car_row_bus[r*8 +: 8] <= sprite_rom[`CAR_START_ANGLE][r];
    end else if (tick_60hz) begin
        // ── Steering ───────────────────────────────────────────────────
        if (steer_left  && !steer_right)
            car_angle <= car_angle - 3'd1;
        else if (steer_right && !steer_left)
            car_angle <= car_angle + 3'd1;

        // ── Speed ──────────────────────────────────────────────────────
        if (accel && !brake) begin
            if (speed_q8 < SPD_MAX) speed_q8 <= speed_q8 + SPD_ACCEL;
        end else if (brake && !accel) begin
            if (speed_q8 > SPD_MIN) speed_q8 <= speed_q8 - SPD_BRAKE;
        end else begin
            if      (speed_q8 >  SPD_DRAG) speed_q8 <= speed_q8 - SPD_DRAG;
            else if (speed_q8 < -SPD_DRAG) speed_q8 <= speed_q8 + SPD_DRAG;
            else                            speed_q8 <= 16'sh0000;
        end

        // ── Position: Q8.8 × Q8.8 = Q16.16 → take [23:8] for Q8.8 ────
        dx_q16 = $signed(speed_q8) * $signed(cos_lut[car_angle]);
        dy_q16 = $signed(speed_q8) * $signed(sin_lut[car_angle]);
        pos_x_q8 <= pos_x_q8 + {{2{dx_q16[33]}}, dx_q16[23:8]};
        pos_y_q8 <= pos_y_q8 + {{2{dy_q16[33]}}, dy_q16[23:8]};

        // Integer pixel coordinates
        car_x <= pos_x_q8[17:8];
        car_y <= pos_y_q8[17:8];

        // Speed in display units (Q8.8 integer part × 25, capped at 99)
        if (speed_q8[15])
            speed_kph <= 8'd0;  // negative speed shows 0
        else if (speed_q8[15:8] >= 8'd4)
            speed_kph <= 8'd99;
        else
            speed_kph <= {speed_q8[11:8], 4'b0} + speed_q8[11:8] * 8'd25;

        // Sprite bus update
        for (r = 0; r < 14; r = r + 1)
            car_row_bus[r*8 +: 8] <= sprite_rom[car_angle][r];
    end
end

endmodule
